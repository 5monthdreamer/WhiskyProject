from django.contrib import admin

# Register your models here.
from labelscanner.models import Photo

admin.site.register(Photo)

